<?php
	$litera = 'W';

	$państwo = 'Wenezuela';
	$miasto = 'Warszawa';
	$rzeka = 'Wisła';
	$imię = 'Władek';
	$kolor = 'wiśnia';
	$roślina = 'winny';
	$zwierzę = 'wiewiórka';
	$czynność = 'wietrzenie';

?>