<?php
	$litera = 'L';
	
	$państwo = 'Luksemburg';
	$miasto = 'Lublin';
	$rzeka = 'Lega';
	$imię = 'Lidia';
	$kolor = 'lazurowy';
	$roślina = 'lilia';
	$zwierzę = 'lew';
	$czynność = 'latanie';

?>